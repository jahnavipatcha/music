package com.cg.music.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.music.entity.Composer;
import com.cg.music.service.ComposerService;

@RestController
public class MusicController {

	@Autowired
	private ComposerService composerService;
	
	@RequestMapping(value="/Composer",method = RequestMethod.POST)
	public Composer createComposer(@RequestBody Composer composer) {
		return composerService.createComposer(composer);
	}
	
	@RequestMapping(value = "/Composer/{composerId}")
	public Optional<Composer> getComposer(@PathVariable int composerId) {
		return composerService.getComposer(composerId);
	}
		
	
	
}
