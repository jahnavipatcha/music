package com.cg.music.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.music.entity.Composer;
@Repository
public interface ComposerRepository extends JpaRepository<Composer, Integer>{

}
