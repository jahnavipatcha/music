package com.cg.music.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.music.entity.Composer;
import com.cg.music.repository.ComposerRepository;

@Service
public class ComposerService {

	@Autowired
	public ComposerRepository composerRepository;

	public Composer createComposer(Composer composer) {
		// TODO Auto-generated method stub
		return composerRepository.save(composer);
	}

	public Optional<Composer> getComposer(int composerId) {
		return composerRepository.findById(composerId);
	}
}
